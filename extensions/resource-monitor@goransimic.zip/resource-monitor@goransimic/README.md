# Resource Monitor

Resource Monitor

## Installation

```sh
git clone https://github.com/goransimic/resource-monitor.git ~./local/share/gnome-shell/extensions/resource-monitor@goransimic

gnome-extensions enable resource-monitor@goransimic
```

