import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';

const ResourceMonitor = GObject.registerClass(
  class ResourceMonitor extends PanelMenu.Button {
    _init() {
      super._init(0.0, _('System Usage'));
      this._box = new St.BoxLayout();
      this._batIndicator = this._createIndicator('battery-symbolic', 'N/A');
      this._box.add_child(this._batIndicator);
      this._gpuIndicator = this._createIndicator('video-display-symbolic', 'N/A');
      this._box.add_child(this._gpuIndicator);
      this.add_child(this._box);
      this._update();
    }

    _update() {
      this._updateBatIndicator();
      this._updateGpuIndicator();
      this.visible = this._box.get_children().some(({ visible }) => visible);

      this._interval = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 3, () => {
        this._update();
        return GLib.SOURCE_REMOVE;
      });
    }

    _createIndicator(icon, text) {
      const box = new St.BoxLayout({ visible: false });
      box.add_child(
        new St.Icon({
          icon_name: icon,
          style_class: 'system-status-icon',
          style: 'margin: 0;',
        }),
      );
      box.add_child(new St.Label({ text, y_align: Clutter.ActorAlign.CENTER }));
      return box;
    }

    _updateBatIndicator() {
      try {
        const decoder = new TextDecoder();
        const current = parseInt(
          decoder.decode(GLib.file_get_contents('/sys/class/power_supply/BAT0/current_now')[1]),
        );
        const voltage = parseInt(
          decoder.decode(GLib.file_get_contents('/sys/class/power_supply/BAT0/voltage_now')[1]),
        );
        const power = ((current * voltage) / 1e12).toFixed(0);
        const status = decoder
          .decode(GLib.file_get_contents('/sys/class/power_supply/BAT0/status')[1])
          .trim();
        const sign = status === 'Full' ? '' : status === 'Charging' ? '+' : '−';
        this._batIndicator.get_child_at_index(1).set_text(`${sign}${power}W`);
        this._batIndicator.visible = !!sign;
      } catch {
        this._batIndicator.get_child_at_index(1).set_text('N/A');
        this._batIndicator.visible = false;
      }
    }

    _updateGpuIndicator() {
      try {
        const decoder = new TextDecoder();
        const status = decoder
          .decode(
            GLib.file_get_contents('/sys/bus/pci/devices/0000:01:00.0/power/runtime_status')[1],
          )
          .trim();
        this._gpuIndicator.get_child_at_index(1).set_text('');
        this._gpuIndicator.visible = status === 'active';
      } catch {
        this._gpuIndicator.get_child_at_index(1).set_text('N/A');
        this._gpuIndicator.visible = false;
      }
    }

    destroy() {
      if (this._interval) {
        GLib.source_remove(this._interval);
        this._interval = null;
      }
      super.destroy();
    }
  },
);

export default class ResourceMonitorExtension extends Extension {
  enable() {
    this._resourceMonitor = new ResourceMonitor();
    Main.panel.addToStatusArea(this.uuid, this._resourceMonitor);
  }

  disable() {
    this._resourceMonitor.destroy();
    this._resourceMonitor = null;
  }
}
