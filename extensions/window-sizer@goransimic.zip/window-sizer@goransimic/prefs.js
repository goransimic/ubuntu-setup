import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import Gtk from 'gi://Gtk';
import GObject from 'gi://GObject';

import { ExtensionPreferences } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class WindowSizerPreferences extends ExtensionPreferences {
  fillPreferencesWindow(window) {
    const settings = this.getSettings();

    const page = new Adw.PreferencesPage({
      title: 'Window Sizer',
      icon_name: 'preferences-desktop-display-symbolic',
    });
    window.add(page);

    const generalSettingsGroup = new Adw.PreferencesGroup({
      title: 'General',
    });
    page.add(generalSettingsGroup);

    // Shortcut
    const shortcutRow = new Adw.ActionRow({
      title: 'Shortcut',
      activatable: true,
    });

    const shortcutLabel = new Adw.ShortcutLabel({
      accelerator: settings.get_strv('shortcut')[0],
      valign: Gtk.Align.CENTER,
      halign: Gtk.Align.CENTER,
    });

    settings.connect('changed::shortcut', () => {
      const shortcut = settings.get_strv('shortcut')[0];
      shortcutLabel.set_accelerator(shortcut);
      shortcutLabel.set_disabled_text(shortcut ? '' : 'Press a shortcut...');
    });

    shortcutRow.connect('activated', () => {
      settings.set_strv('shortcut', ['']);

      const controller = new Gtk.EventControllerKey();
      window.add_controller(controller);
      controller.connect('key-pressed', (_, keyval, keycode, state) => {
        const mask = state & Gtk.accelerator_get_default_mod_mask();

        if (!mask && keyval === Gdk.KEY_Escape) {
          settings.reset('shortcut');
          window.remove_controller(controller);
          return Gdk.EVENT_STOP;
        }

        if (Gtk.accelerator_valid(keyval, mask)) {
          settings.set_strv('shortcut', [
            Gtk.accelerator_name_with_keycode(null, keyval, keycode, mask),
          ]);
          window.remove_controller(controller);
          return Gdk.EVENT_STOP;
        }

        return Gdk.EVENT_STOP;
      });
    });
    shortcutRow.add_suffix(shortcutLabel);
    generalSettingsGroup.add(shortcutRow);

    // Width
    const widthRow = new Adw.SpinRow({
      title: 'Width',
      adjustment: new Gtk.Adjustment({
        value: settings.get_int('width'),
        lower: 1280,
        upper: 7680,
        step_increment: 1,
      }),
    });
    settings.bind('width', widthRow, 'value', GObject.BindingFlags.DEFAULT);
    generalSettingsGroup.add(widthRow);

    // Height
    const heightRow = new Adw.SpinRow({
      title: 'Height',
      adjustment: new Gtk.Adjustment({
        value: settings.get_int('height'),
        lower: 768,
        upper: 4320,
        step_increment: 1,
      }),
    });
    settings.bind('height', heightRow, 'value', GObject.BindingFlags.DEFAULT);
    generalSettingsGroup.add(heightRow);
  }
}
