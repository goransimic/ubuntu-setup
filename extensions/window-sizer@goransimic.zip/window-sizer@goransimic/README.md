# Window Sizer

Window Sizer

## Installation

```sh
git clone https://github.com/goransimic/window-sizer.git ~./local/share/gnome-shell/extensions/window-sizer@goransimic

gnome-extensions enable window-sizer@goransimic
```
