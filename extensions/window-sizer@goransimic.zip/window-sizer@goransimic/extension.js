import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

class WindowSizer {
  constructor(settings) {
    this._panelHeight = Main.panel.height;

    this._settings = settings;
    this._width = this._settings.get_int('width');
    this._height = this._settings.get_int('height');
    this._shortcut = this._settings.get_strv('shortcut')[0];

    this._settings.connect('changed', (settings, key) => {
      switch (key) {
        case 'shortcut':
          Main.wm.removeKeybinding('shortcut');
          Main.wm.addKeybinding(
            'shortcut',
            settings,
            Meta.KeyBindingFlags.NONE,
            Shell.ActionMode.ALL,
            () => this._moveAndResizeWindow(global.display.focus_window),
          );
          break;
        case 'width':
          this._width = settings.get_int('width');
          break;
        case 'height':
          this._height = settings.get_int('height');
          break;
        default:
          break;
      }
    });

    Main.wm.addKeybinding(
      'shortcut',
      this._settings,
      Meta.KeyBindingFlags.NONE,
      Shell.ActionMode.ALL,
      () => this._moveAndResizeWindow(global.display.focus_window),
    );
  }

  _moveAndResizeWindow(window) {
    if (!window || window.get_window_type() !== Meta.WindowType.NORMAL) {
      return;
    }

    const monitorIdx = global.display.get_current_monitor();
    const monitorRect = global.display.get_monitor_geometry(monitorIdx);

    const windowWidth = this._width;
    const windowHeight = this._height;

    const x = monitorRect.x + Math.floor((monitorRect.width - windowWidth) / 2);
    const y =
      monitorRect.y +
      Math.floor((monitorRect.height - windowHeight) / 2) +
      Math.floor(this._panelHeight / 2);

    const isMaximized = window.is_maximized();
    const isOnCurrentMonitor = window.get_monitor() === monitorIdx;

    const shouldMaximize = isMaximized ? !isOnCurrentMonitor : isOnCurrentMonitor;

    if (isMaximized) {
      window.unmaximize();
    }

    window.move_resize_frame(true, x, y, windowWidth, windowHeight);

    if (shouldMaximize) {
      GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
        window.maximize();
        return GLib.SOURCE_REMOVE;
      });
    }
  }

  destroy() {
    Main.wm.removeKeybinding('shortcut');
  }
}

export default class WindowSizerExtension extends Extension {
  enable() {
    this._windowSizer = new WindowSizer(this.getSettings());
  }

  disable() {
    this._windowSizer.destroy();
    this._windowSizer = null;
  }
}
