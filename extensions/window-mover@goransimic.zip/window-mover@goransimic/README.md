# Window Mover

Window Mover

## Installation

```sh
git clone https://github.com/goransimic/window-mover.git ~./local/share/gnome-shell/extensions/window-mover@goransimic

gnome-extensions enable window-mover@goransimic
```

