import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

class WindowMover {
  constructor(settings) {
    this._settings = settings;

    Main.wm.addKeybinding(
      'move-window-hotkey',
      this._settings,
      Meta.KeyBindingFlags.NONE,
      Shell.ActionMode.ALL,
      () => this._moveWindow(global.display.focus_window),
    );
  }

  _moveWindow(window) {
    if (!window || window.get_window_type() !== Meta.WindowType.NORMAL) return;

    const monitorIdx = global.display.get_current_monitor();
    const monitorRect = global.display.get_monitor_geometry(monitorIdx);

    const width = 1280;
    const height = 768;
    const x = monitorRect.x + Math.floor((monitorRect.width - width) / 2);
    const y =
      monitorRect.y +
      Math.floor((monitorRect.height - height) / 2) +
      Math.floor(Main.panel.actor.height / 2);

    const isMaximized = window.get_maximized() & Meta.MaximizeFlags.BOTH;
    const isCurrentMonitor = window.get_monitor() === monitorIdx;
    const shouldMaximize = isMaximized ? !isCurrentMonitor : isCurrentMonitor;

    if (isMaximized) window.unmaximize(Meta.MaximizeFlags.BOTH);
    window.move_resize_frame(true, x, y, width, height);
    GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
      if (shouldMaximize) window.maximize(Meta.MaximizeFlags.BOTH);
      return GLib.SOURCE_REMOVE;
    });
  }

  destroy() {
    Main.wm.removeKeybinding('move-window-hotkey');
  }
}

export default class WindowMoverExtension extends Extension {
  enable() {
    this._windowMover = new WindowMover(this.getSettings());
  }

  disable() {
    this._windowMover.destroy();
    this._windowMover = null;
  }
}
